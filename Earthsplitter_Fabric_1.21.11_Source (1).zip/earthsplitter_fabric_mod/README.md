# Earthsplitter & Storm Mace — Fabric 1.21.11

Paket proyek/source mod untuk Minecraft Java 1.21.11 + Fabric.

### Isi mod
- **Earthsplitter**: pedang dengan efek gelombang tanah saat mengenai mob. Efek memecahkan area kecil blok terrain umum di bawah sekitar target; blok ber-Block Entity dan blok di luar daftar aman tidak disentuh.
- **Thunder Mace**: gada dengan bonus damage, efek melontarkan target, sambaran petir visual, dan partikel listrik saat dipegang.
- Kedua item terdaftar di tab Combat dan memiliki ikon pixel-art sederhana.

### Cara membangun file JAR
1. Gunakan Java 21.
2. Buka folder proyek ini di IntelliJ IDEA atau terminal yang memiliki Gradle.
3. Jalankan `gradle build` (koneksi internet diperlukan untuk mengambil dependensi).
4. Jika berhasil, JAR ada di `build/libs/`.
5. Pasang JAR tersebut bersama Fabric API yang sesuai di folder `.minecraft/mods`.

### Status
Ini **source project ZIP**, bukan JAR yang sudah dikompilasi atau diuji di dalam game. Lingkungan pembuatan ini tidak memiliki akses untuk mengunduh dependensi Gradle dan menjalankan uji Minecraft, jadi kompatibilitas runtime belum dapat dijamin. Fabric 1.21.11 memakai Java 21; lihat dokumentasi resmi Fabric untuk detail versi dan perubahan pemetaan:
https://www.fabricmc.net/2025/12/05/12111.html

**Peringatan:** efek Earthsplitter mengubah terrain. Uji di world salinan terlebih dahulu.
