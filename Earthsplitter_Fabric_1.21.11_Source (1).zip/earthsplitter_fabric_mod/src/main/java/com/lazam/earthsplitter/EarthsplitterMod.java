package com.lazam.earthsplitter;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.item.ItemGroups;
import net.minecraft.util.Identifier;

public class EarthsplitterMod implements ModInitializer {
    public static final String MOD_ID = "earthsplitter";

    public static final Item EARTHSPLITTER = Registry.register(
        Registries.ITEM, Identifier.of(MOD_ID, "earthsplitter"),
        new EarthsplitterSwordItem(ToolMaterials.NETHERITE,
            new Item.Settings().attributeModifiers(SwordItem.createAttributeModifiers(ToolMaterials.NETHERITE, 8, -2.4f)).maxDamage(2600))
    );

    public static final Item THUNDER_MACE = Registry.register(
        Registries.ITEM, Identifier.of(MOD_ID, "thunder_mace"),
        new ThunderMaceItem(new Item.Settings().maxDamage(1800))
    );

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(EARTHSPLITTER);
            entries.add(THUNDER_MACE);
        });
    }
}
