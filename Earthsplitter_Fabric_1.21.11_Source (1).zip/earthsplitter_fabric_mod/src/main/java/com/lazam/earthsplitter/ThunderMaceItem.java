package com.lazam.earthsplitter;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;

public class ThunderMaceItem extends Item {
    public ThunderMaceItem(Settings settings) { super(settings); }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean result = super.postHit(stack, target, attacker);
        if (!attacker.getWorld().isClient && attacker instanceof PlayerEntity player) {
            // Summon a visual lightning bolt at the struck target; the bolt is cosmetic
            // and does not ignite blocks or deal its own vanilla lightning damage.
            LightningEntity bolt = EntityTypeAccess.createLightning(player);
            if (bolt != null) {
                bolt.refreshPositionAfterTeleport(target.getX(), target.getY(), target.getZ());
                bolt.setCosmetic(true);
                player.getWorld().spawnEntity(bolt);
            }
            target.addVelocity(0.0, 0.85, 0.0);
            target.velocityModified = true;
            target.damage(player.getDamageSources().playerAttack(player), 7.0f);
            stack.damage(2, player);
        }
        return result;
    }

    @Override
    public void inventoryTick(ItemStack stack, net.minecraft.world.World world, Entity entity, int slot, boolean selected) {
        if (world.isClient && selected && entity instanceof PlayerEntity player && world.getTime() % 12 == 0) {
            Vec3d p = player.getPos().add(0, 1.0, 0);
            world.addParticle(net.minecraft.particle.ParticleTypes.ELECTRIC_SPARK,
                p.x + (world.random.nextDouble() - .5) * .35, p.y,
                p.z + (world.random.nextDouble() - .5) * .35, 0, .025, 0);
        }
    }
}
