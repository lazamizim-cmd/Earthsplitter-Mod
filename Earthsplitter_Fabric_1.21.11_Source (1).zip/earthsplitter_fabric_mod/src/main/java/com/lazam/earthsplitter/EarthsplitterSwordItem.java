package com.lazam.earthsplitter;

import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class EarthsplitterSwordItem extends SwordItem {
    public EarthsplitterSwordItem(ToolMaterial material, Settings settings) {
        super(material, settings);
    }

    @Override
    public boolean postHit(ItemStack stack, net.minecraft.entity.LivingEntity target, net.minecraft.entity.LivingEntity attacker) {
        boolean result = super.postHit(stack, target, attacker);
        if (attacker instanceof PlayerEntity player && !player.getWorld().isClient) {
            World world = player.getWorld();
            BlockPos center = target.getBlockPos();
            // Cinematic shockwave: break a shallow 5x5 patch of ordinary terrain around the hit.
            // Protected/valuable blocks and block entities are deliberately excluded.
            for (int radius = 0; radius <= 2; radius++) {
                for (int dx = -2; dx <= 2; dx++) {
                    for (int dz = -2; dz <= 2; dz++) {
                        if (Math.max(Math.abs(dx), Math.abs(dz)) != radius) continue;
                        BlockPos pos = center.add(dx, -1, dz);
                        BlockState state = world.getBlockState(pos);
                        if (isSafeTerrain(state, world, pos) && world.getBlockEntity(pos) == null) {
                            world.breakBlock(pos, true, player);
                        }
                    }
                }
            }
            stack.damage(2, player);
        }
        return result;
    }

    private boolean isSafeTerrain(BlockState state, World world, BlockPos pos) {
        if (state.isAir() || state.getHardness(world, pos) < 0) return false;
        String id = net.minecraft.registry.Registries.BLOCK.getId(state.getBlock()).toString();
        return id.endsWith(":dirt") || id.endsWith(":grass_block") || id.endsWith(":stone")
            || id.endsWith(":cobblestone") || id.endsWith(":deepslate") || id.endsWith(":sand")
            || id.endsWith(":gravel") || id.endsWith(":netherrack") || id.endsWith(":end_stone")
            || id.endsWith(":coarse_dirt") || id.endsWith(":rooted_dirt");
    }
}
