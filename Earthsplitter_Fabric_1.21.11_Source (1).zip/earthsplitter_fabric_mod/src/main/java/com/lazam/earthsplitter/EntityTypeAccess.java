package com.lazam.earthsplitter;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.player.PlayerEntity;

final class EntityTypeAccess {
    private EntityTypeAccess() {}
    static LightningEntity createLightning(PlayerEntity player) {
        return EntityType.LIGHTNING_BOLT.create(player.getWorld());
    }
}
